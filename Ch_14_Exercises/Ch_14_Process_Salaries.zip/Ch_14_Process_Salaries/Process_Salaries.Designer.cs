﻿namespace Ch_14_Process_Salaries
{
    partial class Process_Salaries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.lblSalary = new System.Windows.Forms.Label();
            this.lblYears = new System.Windows.Forms.Label();
            this.lblJobType = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.txtYears = new System.Windows.Forms.TextBox();
            this.btnAddPerson = new System.Windows.Forms.Button();
            this.btnCurrnetList = new System.Windows.Forms.Button();
            this.btnUpdatePerson = new System.Windows.Forms.Button();
            this.btnClearList = new System.Windows.Forms.Button();
            this.lstResults = new System.Windows.Forms.ListBox();
            this.cboJobType = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(9, 41);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(38, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.Location = new System.Drawing.Point(9, 68);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(39, 13);
            this.lblSalary.TabIndex = 1;
            this.lblSalary.Text = "Salary:";
            // 
            // lblYears
            // 
            this.lblYears.AutoSize = true;
            this.lblYears.Location = new System.Drawing.Point(9, 92);
            this.lblYears.Name = "lblYears";
            this.lblYears.Size = new System.Drawing.Size(58, 26);
            this.lblYears.TabIndex = 2;
            this.lblYears.Text = "Years \r\nof Service:";
            // 
            // lblJobType
            // 
            this.lblJobType.AutoSize = true;
            this.lblJobType.Location = new System.Drawing.Point(9, 129);
            this.lblJobType.Name = "lblJobType";
            this.lblJobType.Size = new System.Drawing.Size(54, 13);
            this.lblJobType.TabIndex = 3;
            this.lblJobType.Text = "Job Type:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(90, 41);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 4;
            // 
            // txtSalary
            // 
            this.txtSalary.Location = new System.Drawing.Point(90, 67);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(100, 20);
            this.txtSalary.TabIndex = 5;
            // 
            // txtYears
            // 
            this.txtYears.Location = new System.Drawing.Point(90, 98);
            this.txtYears.Name = "txtYears";
            this.txtYears.Size = new System.Drawing.Size(100, 20);
            this.txtYears.TabIndex = 6;
            // 
            // btnAddPerson
            // 
            this.btnAddPerson.Location = new System.Drawing.Point(236, 36);
            this.btnAddPerson.Name = "btnAddPerson";
            this.btnAddPerson.Size = new System.Drawing.Size(113, 23);
            this.btnAddPerson.TabIndex = 8;
            this.btnAddPerson.Text = "Add Person";
            this.btnAddPerson.UseVisualStyleBackColor = true;
            this.btnAddPerson.Click += new System.EventHandler(this.btnAddPerson_Click);
            // 
            // btnCurrnetList
            // 
            this.btnCurrnetList.Location = new System.Drawing.Point(236, 65);
            this.btnCurrnetList.Name = "btnCurrnetList";
            this.btnCurrnetList.Size = new System.Drawing.Size(113, 23);
            this.btnCurrnetList.TabIndex = 9;
            this.btnCurrnetList.Text = "Current List";
            this.btnCurrnetList.UseVisualStyleBackColor = true;
            this.btnCurrnetList.Click += new System.EventHandler(this.btnCurrnetList_Click);
            // 
            // btnUpdatePerson
            // 
            this.btnUpdatePerson.Location = new System.Drawing.Point(236, 98);
            this.btnUpdatePerson.Name = "btnUpdatePerson";
            this.btnUpdatePerson.Size = new System.Drawing.Size(113, 23);
            this.btnUpdatePerson.TabIndex = 10;
            this.btnUpdatePerson.Text = "Update Person";
            this.btnUpdatePerson.UseVisualStyleBackColor = true;
            this.btnUpdatePerson.Click += new System.EventHandler(this.btnUpdatePerson_Click);
            // 
            // btnClearList
            // 
            this.btnClearList.Location = new System.Drawing.Point(236, 129);
            this.btnClearList.Name = "btnClearList";
            this.btnClearList.Size = new System.Drawing.Size(113, 23);
            this.btnClearList.TabIndex = 11;
            this.btnClearList.Text = "Clear List";
            this.btnClearList.UseVisualStyleBackColor = true;
            this.btnClearList.Click += new System.EventHandler(this.btnClearList_Click);
            // 
            // lstResults
            // 
            this.lstResults.FormattingEnabled = true;
            this.lstResults.Location = new System.Drawing.Point(12, 174);
            this.lstResults.Name = "lstResults";
            this.lstResults.Size = new System.Drawing.Size(512, 251);
            this.lstResults.TabIndex = 12;
            // 
            // cboJobType
            // 
            this.cboJobType.FormattingEnabled = true;
            this.cboJobType.Location = new System.Drawing.Point(90, 126);
            this.cboJobType.Name = "cboJobType";
            this.cboJobType.Size = new System.Drawing.Size(100, 21);
            this.cboJobType.TabIndex = 13;
            // 
            // Process_Salaries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 450);
            this.Controls.Add(this.cboJobType);
            this.Controls.Add(this.lstResults);
            this.Controls.Add(this.btnClearList);
            this.Controls.Add(this.btnUpdatePerson);
            this.Controls.Add(this.btnCurrnetList);
            this.Controls.Add(this.btnAddPerson);
            this.Controls.Add(this.txtYears);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblJobType);
            this.Controls.Add(this.lblYears);
            this.Controls.Add(this.lblSalary);
            this.Controls.Add(this.lblName);
            this.Name = "Process_Salaries";
            this.Text = "Process Salaries";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.Label lblYears;
        private System.Windows.Forms.Label lblJobType;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.TextBox txtYears;
        private System.Windows.Forms.Button btnAddPerson;
        private System.Windows.Forms.Button btnCurrnetList;
        private System.Windows.Forms.Button btnUpdatePerson;
        private System.Windows.Forms.Button btnClearList;
        private System.Windows.Forms.ListBox lstResults;
        private System.Windows.Forms.ComboBox cboJobType;
    }
}

