﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch_14_Process_Salaries
{
    public partial class Process_Salaries : Form
    {
        private List<Employee> employees = new List<Employee>();
        public Process_Salaries()
        {
            InitializeComponent();
            InitializeDropDown();
        }
        private void InitializeDropDown()
        {
            List<string> jobTypes = new List<string> { "Employee", "Manager", "Executive" };
            cboJobType.DataSource = jobTypes;
            cboJobType.SelectedIndex = 0;
        }

        private void btnAddPerson_Click(object sender, EventArgs e)
        {
            Employee employee;
            string name = txtName.Text;
            double salary = double.Parse(txtSalary.Text);
            int yearsOfService = int.Parse(txtYears.Text);
            string employeeType = cboJobType.SelectedItem.ToString();

            switch (employeeType)
            {
                case "Manager":
                    employee = new Manager(name, salary, yearsOfService);
                    break;
                case "Executive":
                    employee = new Executive(name, salary, yearsOfService);
                    break;
                default:
                    employee = new Employee(name, salary, yearsOfService);
                    break;
            }

            employees.Add(employee);
        }

        private void btnCurrnetList_Click(object sender, EventArgs e)
        {
            lstResults.Items.Clear();
            foreach (var emp in employees)
            {
                lstResults.Items.Add(emp.ToString());
            }
        }

        private void btnUpdatePerson_Click(object sender, EventArgs e)
        {
            if (lstResults.SelectedIndex != -1)
            {
                double newSalary = double.Parse(txtSalary.Text);
                employees[lstResults.SelectedIndex].Salary = newSalary;
            }
        }

        private void btnClearList_Click(object sender, EventArgs e)
        {
            lstResults.Items.Clear();
        }
    }
}
