﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch_14_Process_Salaries
{
    internal class Executive : Manager
    {
        public Executive(string name, double salary, int yearsOfService) : base(name, salary, yearsOfService)
        {
        }

        public override string ToString()
        {
            return $"The Big Boss Name is: {Name}  \nSalary is: ${Salary}  \nHas worked for: {YearsOfService} years of service.";
        }
    }

}
