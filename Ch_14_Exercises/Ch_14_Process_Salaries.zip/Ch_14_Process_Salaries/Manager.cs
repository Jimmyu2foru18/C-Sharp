﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication.ExtendedProtection.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Ch_14_Process_Salaries
{
    internal class Manager : Employee
    {
        public Manager(string name, double salary, int yearsOfService) : base(name, salary, yearsOfService)
        {
        }

        public override string ToString()
        {
            return $"The Managers Name is: {Name}  \nSalary is: ${Salary}  \nHas worked for: {YearsOfService} years of service.";
        }
    }
}
