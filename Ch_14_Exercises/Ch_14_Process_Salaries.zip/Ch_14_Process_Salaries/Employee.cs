﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch_14_Process_Salaries
{
    internal class Employee
    {
        public string Name { get; set; }
        public double Salary { get; set; }
        public int YearsOfService { get; set; }

        public Employee(string name, double salary, int yearsOfService) 
        {
            Name = name;
            Salary = salary;
            YearsOfService = yearsOfService;
        }

        public override string ToString()
        {

            return $"{Name}  \nSalary is: ${Salary}  \nHas worked for: {YearsOfService} years of service.";
        }
    }
}
