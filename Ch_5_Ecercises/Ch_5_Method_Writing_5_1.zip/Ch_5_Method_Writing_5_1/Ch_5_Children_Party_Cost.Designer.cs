﻿namespace Ch_5_Method_Writing_5_1
{
    partial class Ch_5_Children_Party_Cost
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnComputePrice = new System.Windows.Forms.Button();
            this.txtAdults = new System.Windows.Forms.TextBox();
            this.txtChildren = new System.Windows.Forms.TextBox();
            this.lblAdult = new System.Windows.Forms.Label();
            this.lblChildren = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnComputePrice
            // 
            this.btnComputePrice.Location = new System.Drawing.Point(15, 97);
            this.btnComputePrice.Name = "btnComputePrice";
            this.btnComputePrice.Size = new System.Drawing.Size(200, 69);
            this.btnComputePrice.TabIndex = 0;
            this.btnComputePrice.Text = "Compute Price";
            this.btnComputePrice.UseVisualStyleBackColor = true;
            this.btnComputePrice.Click += new System.EventHandler(this.btnComputePrice_Click);
            // 
            // txtAdults
            // 
            this.txtAdults.Location = new System.Drawing.Point(120, 17);
            this.txtAdults.Name = "txtAdults";
            this.txtAdults.Size = new System.Drawing.Size(113, 20);
            this.txtAdults.TabIndex = 1;
            // 
            // txtChildren
            // 
            this.txtChildren.Location = new System.Drawing.Point(120, 59);
            this.txtChildren.Name = "txtChildren";
            this.txtChildren.Size = new System.Drawing.Size(113, 20);
            this.txtChildren.TabIndex = 2;
            // 
            // lblAdult
            // 
            this.lblAdult.AutoSize = true;
            this.lblAdult.Location = new System.Drawing.Point(12, 24);
            this.lblAdult.Name = "lblAdult";
            this.lblAdult.Size = new System.Drawing.Size(93, 13);
            this.lblAdult.TabIndex = 3;
            this.lblAdult.Text = "How Many Adults:";
            // 
            // lblChildren
            // 
            this.lblChildren.AutoSize = true;
            this.lblChildren.Location = new System.Drawing.Point(3, 62);
            this.lblChildren.Name = "lblChildren";
            this.lblChildren.Size = new System.Drawing.Size(102, 13);
            this.lblChildren.TabIndex = 4;
            this.lblChildren.Text = "How Many Children:";
            // 
            // Ch_5_Children_Party_Cost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(288, 194);
            this.Controls.Add(this.lblChildren);
            this.Controls.Add(this.lblAdult);
            this.Controls.Add(this.txtChildren);
            this.Controls.Add(this.txtAdults);
            this.Controls.Add(this.btnComputePrice);
            this.Name = "Ch_5_Children_Party_Cost";
            this.Text = "Children Party Cost";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnComputePrice;
        private System.Windows.Forms.TextBox txtAdults;
        private System.Windows.Forms.TextBox txtChildren;
        private System.Windows.Forms.Label lblAdult;
        private System.Windows.Forms.Label lblChildren;
    }
}

