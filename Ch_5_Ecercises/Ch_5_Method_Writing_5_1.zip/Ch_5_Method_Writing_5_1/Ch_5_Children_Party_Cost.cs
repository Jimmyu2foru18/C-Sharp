﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
/*
Abstract

Create a form called ChildrenPartyCost that calculate the cost of a childrens party.

The cost is only calculated if there is at least one adult for every 5 children.

The cost of an adult is $50/pp The cost of a child is 30/pp.

Supporting methods need to be written:
    calcPartyTotal
    validParty
    calcAdultPrice
    calcChildPrice
*/

namespace Ch_5_Method_Writing_5_1
{
    public partial class Ch_5_Children_Party_Cost : Form
    {
        public Ch_5_Children_Party_Cost()
        {
            InitializeComponent();
        }

        private bool ValidParty(int adults, int children)
        {
            return true;
        }

        private double CalculateAdultPrice(int adults)
        {
            return adults * 50.0;
        }

        private double CalculateChildPrice(int children)
        {
            return children * 30.0;
        }

        private void CalculatePartyTotal(int adults, int children)
        {
            if (ValidParty(adults, children))
            {
                double adultPrice = CalculateAdultPrice(adults);
                double childPrice = CalculateChildPrice(children);
                double total = adultPrice + childPrice;
                MessageBox.Show("Total Price: " + total.ToString("C"));
            }
            else
            {
                MessageBox.Show("Invalid Input.");
            }
        }

        private void btnComputePrice_Click(object sender, EventArgs e)
        {
            try
            {
                int adults = int.Parse(txtAdults.Text);
                int children = int.Parse(txtChildren.Text);
                CalculatePartyTotal(adults, children);
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid numeric values for adults and children.");
            }
        }
    }
}
