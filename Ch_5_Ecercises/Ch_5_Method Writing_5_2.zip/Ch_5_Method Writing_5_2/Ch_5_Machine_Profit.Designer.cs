﻿namespace Ch_5_Method_Writing_5_2
{
    partial class Ch_5_Machine_Profit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtNumberOfMachines = new System.Windows.Forms.TextBox();
            this.txtPricePerMachine = new System.Windows.Forms.TextBox();
            this.txtNumberOfPeople = new System.Windows.Forms.TextBox();
            this.txtNumberOfWeeks = new System.Windows.Forms.TextBox();
            this.txtPricePerHourPerWorker = new System.Windows.Forms.TextBox();
            this.lstResult = new System.Windows.Forms.ListBox();
            this.lblNumberOfMachines = new System.Windows.Forms.Label();
            this.lblPricePerMachine = new System.Windows.Forms.Label();
            this.lblNumberOfPeople = new System.Windows.Forms.Label();
            this.lblNumberOfWeeks = new System.Windows.Forms.Label();
            this.lblPricePerHourPerWorker = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(73, 262);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(174, 58);
            this.btnCalculate.TabIndex = 0;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // txtNumberOfMachines
            // 
            this.txtNumberOfMachines.Location = new System.Drawing.Point(157, 24);
            this.txtNumberOfMachines.Name = "txtNumberOfMachines";
            this.txtNumberOfMachines.Size = new System.Drawing.Size(124, 20);
            this.txtNumberOfMachines.TabIndex = 1;
            // 
            // txtPricePerMachine
            // 
            this.txtPricePerMachine.Location = new System.Drawing.Point(157, 54);
            this.txtPricePerMachine.Name = "txtPricePerMachine";
            this.txtPricePerMachine.Size = new System.Drawing.Size(124, 20);
            this.txtPricePerMachine.TabIndex = 2;
            // 
            // txtNumberOfPeople
            // 
            this.txtNumberOfPeople.Location = new System.Drawing.Point(157, 91);
            this.txtNumberOfPeople.Name = "txtNumberOfPeople";
            this.txtNumberOfPeople.Size = new System.Drawing.Size(124, 20);
            this.txtNumberOfPeople.TabIndex = 3;
            // 
            // txtNumberOfWeeks
            // 
            this.txtNumberOfWeeks.Location = new System.Drawing.Point(157, 128);
            this.txtNumberOfWeeks.Name = "txtNumberOfWeeks";
            this.txtNumberOfWeeks.Size = new System.Drawing.Size(124, 20);
            this.txtNumberOfWeeks.TabIndex = 4;
            // 
            // txtPricePerHourPerWorker
            // 
            this.txtPricePerHourPerWorker.Location = new System.Drawing.Point(157, 163);
            this.txtPricePerHourPerWorker.Name = "txtPricePerHourPerWorker";
            this.txtPricePerHourPerWorker.Size = new System.Drawing.Size(124, 20);
            this.txtPricePerHourPerWorker.TabIndex = 5;
            // 
            // lstResult
            // 
            this.lstResult.FormattingEnabled = true;
            this.lstResult.Location = new System.Drawing.Point(47, 198);
            this.lstResult.Name = "lstResult";
            this.lstResult.Size = new System.Drawing.Size(241, 56);
            this.lstResult.TabIndex = 6;
            // 
            // lblNumberOfMachines
            // 
            this.lblNumberOfMachines.AutoSize = true;
            this.lblNumberOfMachines.Location = new System.Drawing.Point(44, 31);
            this.lblNumberOfMachines.Name = "lblNumberOfMachines";
            this.lblNumberOfMachines.Size = new System.Drawing.Size(107, 13);
            this.lblNumberOfMachines.TabIndex = 7;
            this.lblNumberOfMachines.Text = "Number Of Machines";
            // 
            // lblPricePerMachine
            // 
            this.lblPricePerMachine.AutoSize = true;
            this.lblPricePerMachine.Location = new System.Drawing.Point(57, 61);
            this.lblPricePerMachine.Name = "lblPricePerMachine";
            this.lblPricePerMachine.Size = new System.Drawing.Size(94, 13);
            this.lblPricePerMachine.TabIndex = 8;
            this.lblPricePerMachine.Text = "Price Per Machine";
            // 
            // lblNumberOfPeople
            // 
            this.lblNumberOfPeople.AutoSize = true;
            this.lblNumberOfPeople.Location = new System.Drawing.Point(57, 98);
            this.lblNumberOfPeople.Name = "lblNumberOfPeople";
            this.lblNumberOfPeople.Size = new System.Drawing.Size(94, 13);
            this.lblNumberOfPeople.TabIndex = 9;
            this.lblNumberOfPeople.Text = "Number Of People";
            // 
            // lblNumberOfWeeks
            // 
            this.lblNumberOfWeeks.AutoSize = true;
            this.lblNumberOfWeeks.Location = new System.Drawing.Point(56, 135);
            this.lblNumberOfWeeks.Name = "lblNumberOfWeeks";
            this.lblNumberOfWeeks.Size = new System.Drawing.Size(95, 13);
            this.lblNumberOfWeeks.TabIndex = 10;
            this.lblNumberOfWeeks.Text = "Number Of Weeks";
            // 
            // lblPricePerHourPerWorker
            // 
            this.lblPricePerHourPerWorker.AutoSize = true;
            this.lblPricePerHourPerWorker.Location = new System.Drawing.Point(18, 163);
            this.lblPricePerHourPerWorker.Name = "lblPricePerHourPerWorker";
            this.lblPricePerHourPerWorker.Size = new System.Drawing.Size(133, 13);
            this.lblPricePerHourPerWorker.TabIndex = 11;
            this.lblPricePerHourPerWorker.Text = "Price Per Hour Per Worker";
            // 
            // Ch_5_Machine_Profit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 332);
            this.Controls.Add(this.lblPricePerHourPerWorker);
            this.Controls.Add(this.lblNumberOfWeeks);
            this.Controls.Add(this.lblNumberOfPeople);
            this.Controls.Add(this.lblPricePerMachine);
            this.Controls.Add(this.lblNumberOfMachines);
            this.Controls.Add(this.lstResult);
            this.Controls.Add(this.txtPricePerHourPerWorker);
            this.Controls.Add(this.txtNumberOfWeeks);
            this.Controls.Add(this.txtNumberOfPeople);
            this.Controls.Add(this.txtPricePerMachine);
            this.Controls.Add(this.txtNumberOfMachines);
            this.Controls.Add(this.btnCalculate);
            this.Name = "Ch_5_Machine_Profit";
            this.Text = "Machine Profit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox txtNumberOfMachines;
        private System.Windows.Forms.TextBox txtPricePerMachine;
        private System.Windows.Forms.TextBox txtNumberOfPeople;
        private System.Windows.Forms.TextBox txtNumberOfWeeks;
        private System.Windows.Forms.TextBox txtPricePerHourPerWorker;
        private System.Windows.Forms.ListBox lstResult;
        private System.Windows.Forms.Label lblNumberOfMachines;
        private System.Windows.Forms.Label lblPricePerMachine;
        private System.Windows.Forms.Label lblNumberOfPeople;
        private System.Windows.Forms.Label lblNumberOfWeeks;
        private System.Windows.Forms.Label lblPricePerHourPerWorker;
    }
}
