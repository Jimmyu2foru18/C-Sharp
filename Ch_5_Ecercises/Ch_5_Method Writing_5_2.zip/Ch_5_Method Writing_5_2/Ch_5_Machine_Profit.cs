﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
Abstract
Create a form called MachineProfit. 

This will determine if the number of machines sold at a certain price will make a profit. 

In order to make a profit, 
the amount of machines sold will have to exceed the budget of $100,000 in materials 
plus the amount it costs for the manpower to make the machines.

Manpower consists of the number of people working on the machines 
40 hours per week  8 hours per day at a rate per hour.

The form should ask for the number of machines to be sold, the price per machine, 
the number of people that will be working on the machine, 
the number of weeks it will take to complete the job, 
and the price per hour for each worker. 

The form will then output the profit gained or profit lost by the venture.
Be sure to create methods that will help your program run in a top-down design fashion. 
*/

namespace Ch_5_Method_Writing_5_2
{
    public partial class Ch_5_Machine_Profit : Form
    {
        public Ch_5_Machine_Profit()
        {
            InitializeComponent();
        }

        private bool ValidateInput()
        {
            if (!ValidateInput(txtNumberOfMachines, "Number of machines") ||
                !ValidateInput(txtPricePerMachine, "Price per machine") ||
                !ValidateInput(txtNumberOfPeople, "Number of people working") ||
                !ValidateInput(txtNumberOfWeeks, "Number of weeks") ||
                !ValidateInput(txtPricePerHourPerWorker, "Price per hour per worker"))
                return false;

            return true;
        }

        private bool ValidateInput(TextBox textBox, string fieldName)
        {
            if (!int.TryParse(textBox.Text, out int value) || value < 0)
            {
                MessageBox.Show($"Invalid input for '{fieldName}'. Please enter a non-negative integer.");
                return false;
            }
            return true;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (!ValidateInput())
                return;

            int numberOfMachinesSold = int.Parse(txtNumberOfMachines.Text);
            double pricePerMachine = double.Parse(txtPricePerMachine.Text);
            int numberOfPeopleWorking = int.Parse(txtNumberOfPeople.Text);
            int numberOfWeeks = int.Parse(txtNumberOfWeeks.Text);
            double pricePerHourPerWorker = double.Parse(txtPricePerHourPerWorker.Text);

            double materialsCost = numberOfMachinesSold * pricePerMachine;
            double manpowerCost = numberOfPeopleWorking * 40 * 8 * numberOfWeeks * pricePerHourPerWorker;
            double totalCost = materialsCost + manpowerCost;

            double profitOrLoss = totalCost - 100000;

            lstResult.Items.Clear(); // Clear previous results
            lstResult.Items.Add(profitOrLoss > 0 ? $"Profit gained: {profitOrLoss:C}" : $"Profit lost: {-profitOrLoss:C}");
        }
    }
}
