﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/* For a Hotel Discount form 
 * 
 *   Create a discount type ; AAA, Best Rate, senior, government or no discount
 *                           10%    5%      15%     12.5%          0
 *   Hotel price per night is $ 150.00
 *   Switch Case
 * 
 */

namespace Ch_5_Class_Exercise_1
{
    public partial class Ch_5_Hotel_Discount : Form
    {


        public Ch_5_Hotel_Discount()
        {
            InitializeComponent();
        }
        /* 
        Professor Design:
        private void button1_Click(object sender, EventArgs e)
        {
           1 Discount: 
           double disc = calcDiscount();
            
           2 Room Rate:
            double rate = CalcRoom Rate(disc);
            
           3 Output to textbox
            txtResults.Text = $": ${discountedPrice:F2}";
            
        }
        private double calcDiscount()
          { 
            double dis = 0;
          {
            switch (txtDiscount.Text)
                {
                    case "AAA":
                        dis = AAA;
                        break;

                    case "Best Rate":
                        dis = BestRate;
                        break;

                    case "Government":
                        dis = Government;
                        break;

                    case "Senior":
                        dis = Senior;
                        break;

                    default:
                        dis = 0;
                        break;
                }
                return dis;
            }
        }
         */

        private void button1_Click(object sender, EventArgs e)
        {
            /*  
            Declare data types 

            const float Hotel = 150f;
            const float AAA = 10f;
            const float BestRate = 5f;
            const float Government = 15f;
            const float Senior = 12.5f;
            */

            // Get the selected discount type
            string discountType = txtDiscount.Text;

            // Calculate the discounted price
            float discountPercent = 0;

            switch (discountType)
            {
                case "AAA":
                    discountPercent = 10;
                    break;

                case "Best Rate":
                    discountPercent = 5;
                    break;

                case "Government":
                    discountPercent = 15;
                    break;

                case "Senior":
                    discountPercent = 12.5f;
                    break;

                default:
                    discountPercent = 0;
                    break;
            }

            float discountedPrice = 150 - (150 * discountPercent / 100f);

            // Display the result
            txtResults.Text = $"${discountedPrice:F2}";
        }
    }}
