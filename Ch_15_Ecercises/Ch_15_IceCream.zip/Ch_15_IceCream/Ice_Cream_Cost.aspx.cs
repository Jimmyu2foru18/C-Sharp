﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ch_15_IceCream
{
    public partial class Ice_Cream_Cost : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int scoops;
            double unitPrice, cost;

            scoops = int.Parse(txtScoops.Text);
            unitPrice = double.Parse(txtUnitPrice.Text);

            cost = unitPrice * scoops;
            lblCost.Text = cost.ToString("C";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }
    }
}