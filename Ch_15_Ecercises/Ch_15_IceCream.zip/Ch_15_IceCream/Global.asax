﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Ch_15_IceCream.Global" Language="C#" %>
