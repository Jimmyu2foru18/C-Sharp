﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ch_15_Exercise_15_1
{
    public partial class Job_Cost : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        // txtCostOfLabor,txtMaterials,lblSubtotalTotal,lblSalesTaxTotal,lblTotalCostTotal
        protected void btnComputeCost_Click(object sender, EventArgs e)
        {
            // Get the values from textboxes
            decimal costOfLabor = decimal.Parse(txtCostOfLabor.Text);
            decimal materials = decimal.Parse(txtMaterials.Text);

            // Calculate subtotal
            decimal subtotal = costOfLabor + materials;
            lblSubtotalTotal.Text = subtotal.ToString("c"); // Display subtotal

            // Calculate sales tax (assuming 10%)
            decimal salesTaxRate = 0.1m;
            decimal salesTax = subtotal * salesTaxRate;
            lblSalesTaxTotal.Text = salesTax.ToString("c"); // Display sales tax

            // Calculate total cost
            decimal totalCost = subtotal + salesTax;
            lblTotalCostTotal.Text = totalCost.ToString("c"); // Display total cost
        }
        protected void btnClear_Click(object sender, EventArgs e)
        {
            // Clear textboxes and labels
            txtCostOfLabor.Text = "";
            txtMaterials.Text = "";
            lblSubtotalTotal.Text = "";
            lblSalesTaxTotal.Text = "";
            lblTotalCostTotal.Text = "";
        }

        protected void btnExit_Click(object sender, EventArgs e)
        {
            // Close the browser window or redirect to another page
            Response.Redirect("https://www.example.com"); // Redirect to an example page
        }
    }
}