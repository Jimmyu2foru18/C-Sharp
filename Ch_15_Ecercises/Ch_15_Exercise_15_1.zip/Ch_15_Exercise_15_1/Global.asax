﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Ch_15_Exercise_15_1.Global" Language="C#" %>
