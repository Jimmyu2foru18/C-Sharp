﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Job Cost.aspx.cs" Inherits="Ch_15_Exercise_15_1.Job_Cost" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Job Cost</title>
    <style type="text/css">
        .auto-style1 {
            margin-left: 40px;
        }
        .auto-style2 {
            width: 572px;
            height: 151px;
            border: 1px solid #000000;
            background-color: #FFFFFF;
        }
        .auto-style5 {
            width: 142px;
        }
        .auto-style6 {
            width: 141px;
        }
        .auto-style7 {
            width: 193px;
        }
        .auto-style8 {
            width: 148px;
        }
        .auto-style9 {
            height: 20px;
        }
        .auto-style10 {
            width: 193px;
            height: 20px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            Job Cost Example<table class="auto-style2">
                <tr>
                    <td class="auto-style5">
        <asp:Label ID="lblCostOfLabor" runat="server" Text="Cost of Labor:"></asp:Label>
                    </td>
                    <td class="auto-style6">
        <asp:TextBox ID="txtCostOfLabor" runat="server"></asp:TextBox>
                    </td>
                    <td class="auto-style8">
        <asp:Label ID="lblSubtotal" runat="server" Text="Subtotal:"></asp:Label>
                    </td>
                    <td class="auto-style7">
                        <asp:Label ID="lblSubtotalTotal" runat="server"></asp:Label>
                    </td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td class="auto-style5">
        <asp:Label ID="lblMaterials" runat="server" Text="Materials:"></asp:Label>
                    </td>
                    <td class="auto-style6">
        <asp:TextBox ID="txtMaterials" runat="server"></asp:TextBox>
                    </td>
                    <td class="auto-style8">
        <asp:Label ID="lblSalesTax" runat="server" Text="Sales Tax:"></asp:Label>
                    </td>
                    <td class="auto-style7">
                        <asp:Label ID="lblSalesTaxTotal" runat="server"></asp:Label>
                    </td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td class="auto-style5">&nbsp;</td>
                    <td class="auto-style6">&nbsp;</td>
                    <td class="auto-style8">
        <asp:Label ID="lblTotalCost" runat="server" Text="Total Cost:"></asp:Label>
                    </td>
                    <td class="auto-style7">
                        <asp:Label ID="lblTotalCostTotal" runat="server"></asp:Label>
                    </td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td class="auto-style5">&nbsp;</td>
                    <td class="auto-style6">&nbsp;&nbsp;&nbsp;</td>
                    <td class="auto-style8">&nbsp;</td>
                    <td class="auto-style7">&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <asp:Button ID="btnComputeCost" runat="server" Text="Compute Cost" Width="135px" OnClick="btnComputeCost_Click" />
&nbsp;
        <asp:Button ID="btnClear" runat="server" Text="Clear" Width="86px" OnClick="btnClear_Click" />
&nbsp;<asp:Button ID="btnExit" runat="server" Text="Exit" Width="88px" OnClick="btnExit_Click" />
                    </td>
                    <td class="auto-style7">&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td class="auto-style9" colspan="3"></td>
                    <td class="auto-style10"></td>
                    <td class="auto-style9"></td>
                </tr>
            </table>
        </div>
        <p class="auto-style1">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;
&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <br />
        <br />
            &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
        </p>
    </form>
</body>
</html>
