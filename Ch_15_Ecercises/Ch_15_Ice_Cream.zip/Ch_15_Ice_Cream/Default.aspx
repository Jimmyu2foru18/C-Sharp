﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="Default.aspx.vb" Inherits="Ch_15_Ice_Cream._Default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>I like ice cream</title>
    <meta name ="Description " content =" Compute Icecream Cost"  />
    <meta name ="Keywords " content =" web form, Compute Costt, Ice Cream Cost"  />
    <meta charset =" utf-8"  />

    <style type="text/css">
        .auto-style2 {
            width: 498px;
            border-style: solid;
            border-width: 5px;
            height: 227px;
        }
        .auto-style20 {
            width: 160px;
            height: 45px;
        }
        .auto-style26 {
            height: 45px;
            width: 161px;
        }
        .auto-style35 {
            width: 49px;
            height: 45px;
        }
        .auto-style36 {
            height: 45px;
        }
        .auto-style37 {
            width: 108px;
            height: 45px;
        }
        .auto-style38 {
            width: 49px;
            height: 46px;
        }
        .auto-style39 {
            width: 160px;
            height: 46px;
        }
        .auto-style40 {
            width: 161px;
            height: 46px;
        }
        .auto-style41 {
            width: 108px;
            height: 46px;
        }
    </style>


</head>
<body>
    <form id="form1" runat="server">
        <div>
            <table class="auto-style2">
                <tr>
                    <td class="auto-style35">&nbsp;</td>
                    <td colspan="2" class="auto-style36">Ice Cream Cost</td>
                    <td class="auto-style37">
                        <asp:ImageButton ID="ImageButton1" runat="server" Height="84px" ImageUrl="https://handletheheat.com/wp-content/uploads/2021/06/homemade-vanilla-ice-cream.jpg" Width="108px" />
                   </td>
                </tr>
                <tr>
                    <td class="auto-style35"></td>
                    <td class="auto-style20"></td>
                    <td class="auto-style26"></td>
                    <td class="auto-style37"></td>
                </tr>
                <tr>
                    <td class="auto-style35"># of Scoops:</td>
                    <td class="auto-style20">
                        <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
                    </td>
                    <td class="auto-style26">&nbsp;</td>
                    <td class="auto-style37">&nbsp;</td>
                </tr>
                <tr>
                    <td class="auto-style38">Unit Price:</td>
                    <td class="auto-style39">
                        <asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>
                    </td>
                    <td class="auto-style40">Cost:</td>
                    <td class="auto-style41">[lblCost]</td>
                </tr>
                <tr>
                    <td class="auto-style38">&nbsp;</td>
                    <td class="auto-style39">
                        <asp:Button ID="Button1" runat="server" Text="Compute Cost" Width="149px" />
                    </td>
                    <td class="auto-style40">
                        <asp:Button ID="Button2" runat="server" Text="Clear" Width="164px" />
                    </td>
                    <td class="auto-style41">&nbsp;</td>
                </tr>
            </table>
            //How to link a website
            <a href="https://www.google.com">GO</a>
        </div>
    </form>
</body>
</html>
