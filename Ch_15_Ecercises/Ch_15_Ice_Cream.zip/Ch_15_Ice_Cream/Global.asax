﻿<%@ Application Codebehind="Global.asax.vb" Inherits="Ch_15_Ice_Cream.Global_asax" Language="vb" %>
